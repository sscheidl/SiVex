SiVex-Tests: TitraLab 3 / Redoxlabor / Chromatographie / Destillation
Quelle: github.com/sscheidl/SiVex, main, Stand 29.10.2026

MEBIS: Dieses Sammelarchiv zuerst entpacken! Fuer jede Simulation
die Datei unter SCORM_1.2/ unveraendert als Aktivitaet
"Lernpaket (SCORM)" in mebis hochladen; "Neues Fenster" waehlen.
Das aeussere Sammelarchiv NICHT als SCORM hochladen.

HTML / OFFLINE: Das jeweilige ZIP unter WEB_HTML/ entpacken,
dann die index.html der Simulation im Browser starten.

Alle enthaltenen ZIP-Dateien stammen unveraendert aus dem Repository.
TitraLab 3 und Redoxlabor: in mebis/iPad getestet;
Chromatographie und Destillation: noch Status prototype.
