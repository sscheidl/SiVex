SiVex-Tests: Pufferfish / Halbtitration / Trennverfahren
Quelle: github.com/sscheidl/SiVex, main, Stand 29.10.2026

MEBIS: Dieses Sammelarchiv zuerst entpacken! Fuer jede Simulation
die Datei unter SCORM_1.2/ unveraendert als Aktivitaet
"Lernpaket (SCORM)" in mebis hochladen; "Neues Fenster" waehlen.
Das aeussere Sammelarchiv NICHT als SCORM hochladen.

HTML / OFFLINE: Das jeweilige ZIP unter WEB_HTML/ entpacken,
dann die index.html der Simulation im Browser starten.

Alle enthaltenen ZIP-Dateien stammen unveraendert aus dem Repository.
Diese drei Module haben Status "prototype"; Tests auf echten
Schul-iPads, Import in mebis und fachliche Freigabe stehen aus.
